import { motion } from "motion/react";
import { Lightbulb, Flame, Zap, Rocket, Brain, MoveRight } from "lucide-react";

interface Step {
  id: number;
  title: string;
  description?: string;
  icon: any; // Lucide icon
  color: string;
  className: string;
}

const steps: Step[] = [
  {
    id: 1,
    title: "Antes de Innovar: La Semilla",
    description: "Preparando el terreno mental. Desafiando suposiciones y construyendo la resiliencia necesaria para el cambio.",
    icon: Lightbulb,
    color: "#2D6A4F",
    className: "md:col-span-8 bg-brand-surface-low h-[400px]",
  },
  {
    id: 2,
    title: "Encender la Chispa: Ideación y Exploración",
    icon: Flame,
    color: "#D99B2A",
    className: "md:col-span-4 bg-brand-surface-low h-[400px]",
  },
  {
    id: 3,
    title: "En Acción: Desarrollo y Validación",
    icon: Zap,
    color: "#1D4ED8",
    className: "md:col-span-4 bg-brand-surface-low h-[300px]",
  },
  {
    id: 4,
    title: "Lanzar e Impactar: Implementación y Escalabilidad",
    icon: Rocket,
    color: "#EA580C",
    className: "md:col-span-4 bg-brand-surface-low h-[300px]",
  },
  {
    id: 5,
    title: "Después de Innovar: Aprendizaje y Evolución",
    icon: Brain,
    color: "#6D28D9",
    className: "md:col-span-4 bg-brand-surface-low h-[300px]",
  },
];

export default function ExploreGrid() {
  return (
    <section id="explorar" className="mx-auto max-w-screen-2xl px-8 py-40">
      <div className="mb-20 md:w-1/2">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="mb-6 font-serif text-5xl italic leading-tight text-brand-on-surface"
        >
          Explora a tu ritmo
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="font-sans text-xl leading-relaxed text-brand-on-surface-variant opacity-80"
        >
          El camino de la innovación no es lineal. Sumérgete en las fases que resonan contigo hoy.
        </motion.p>
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-12">
        {steps.map((step, index) => (
          <motion.div
            key={step.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className={`group relative flex flex-col justify-between overflow-hidden rounded-xl p-10 shadow-sm transition-all hover:shadow-ambient ${step.className}`}
          >
            {/* Background Number Ornament */}
            <div
              className={`absolute bottom-0 right-0 translate-x-1/4 translate-y-1/4 font-serif text-[12rem] font-bold leading-none opacity-[0.05]`}
              style={{ color: step.color }}
            >
              {step.id}
            </div>

            <div className="relative z-10">
              <step.icon size={32} style={{ color: step.color }} className="mb-6" />
              <h3
                className="mb-4 font-serif text-3xl leading-tight"
                style={{ color: step.color }}
              >
                {step.title}
              </h3>
              {step.description && (
                <p className="max-w-md font-sans text-brand-on-surface-variant opacity-70">
                  {step.description}
                </p>
              )}
            </div>

            <button
              className="relative z-10 mt-8 flex w-fit items-center gap-2 font-sans text-xs font-bold uppercase tracking-widest transition-opacity hover:opacity-70"
              style={{ color: step.color }}
            >
              Explorar <MoveRight size={16} />
            </button>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
