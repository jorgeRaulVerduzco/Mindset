export default function Footer() {
  return (
    <footer className="bg-brand-secondary text-brand-surface-lowest">
      <div className="mx-auto flex max-w-screen-2xl flex-col items-center justify-between gap-8 px-12 py-16 md:flex-row">
        <div className="flex items-center gap-8">
          {/* Miniature Book Cover */}
          <div className="h-24 w-16 overflow-hidden rounded shadow-ambient">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuAxZKRj27q7VITRfm8-_dAyPnh5akeQHzL1aKhpX7agQ8lNuB78FjPQ07yr_U3UgqQ-4BgQMeF6kXKcjkKx5BiVysaG_qc_GA--dZmn2G-ZLbdmahJjekBvgAPNaT1zVWBezct2sRN4FME-qSB6A4oKVUI2yS4oHbX34BESFJJWPS1C9GDSp7h0XwpJAnUAFxV8ZrZSnq5Wx4YCyMMCjmiMnBylTB0DROyljf22r0NGBwt7uOK5z5ZmkmdfOXY31d86026IAjTFioS6"
              alt="Book thumbnail"
              className="h-full w-full object-cover opacity-80"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="mb-1 font-serif text-2xl italic leading-none">Yaqui Valley</div>
            <p className="font-sans text-xs tracking-widest opacity-60">
              © 2024 Yaqui Valley - El Mindset Innovador
            </p>
          </div>
        </div>

        <nav className="flex flex-wrap justify-center gap-x-12 gap-y-4">
          {["Libros", "Metodología", "Contacto", "Privacidad"].map((link) => (
            <a
              key={link}
              href="#"
              className="font-sans text-sm font-medium tracking-wide opacity-70 transition-opacity hover:opacity-100"
            >
              {link}
            </a>
          ))}
        </nav>
      </div>
    </footer>
  );
}
