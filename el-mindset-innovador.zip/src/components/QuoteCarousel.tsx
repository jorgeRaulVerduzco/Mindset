import { useState } from "react";
import { ChevronLeft, ChevronRight, Quote, Heart, Share2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const quotes = [
  {
    text: "Innovar implica correr riesgos y romper reglas.",
    source: "Sección 2 · Página 14",
  },
  {
    text: "La innovación no es solo hacer cosas nuevas, sino hacer las cosas mejor.",
    source: "Sección 1 · Página 5",
  },
  {
    text: "Si no estás fallando, no estás innovando lo suficiente.",
    source: "Sección 4 · Página 42",
  },
  {
    text: "La curiosidad es el motor de la innovación.",
    source: "Sección 3 · Página 28",
  },
];

export default function QuoteCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const nextQuote = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % quotes.length);
  };

  const prevQuote = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + quotes.length) % quotes.length);
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 100 : -100,
      opacity: 0,
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 100 : -100,
      opacity: 0,
    }),
  };

  return (
    <section id="frase" className="bg-brand-surface-low py-32">
      <div className="mx-auto max-w-screen-md px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 inline-flex items-center gap-2 rounded-full bg-brand-surface-lowest px-4 py-2 shadow-ambient"
        >
          <span className="text-xl">🔥</span>
          <span className="font-sans text-sm font-medium text-brand-on-surface">
            Llevas 3 días seguidos leyendo
          </span>
        </motion.div>

        <div className="relative flex items-center justify-center">
          <button
            onClick={prevQuote}
            className="absolute -left-4 z-20 flex h-12 w-12 items-center justify-center rounded-full bg-brand-surface-lowest text-brand-on-surface shadow-ambient transition-all hover:scale-110 hover:text-brand-primary active:scale-95 md:-left-16 md:h-14 md:w-14"
          >
            <ChevronLeft size={24} />
          </button>

          <div className="relative min-h-[400px] w-full overflow-hidden rounded-xl bg-brand-surface-lowest p-12 shadow-ambient">
            <AnimatePresence initial={false} custom={direction}>
              <motion.div
                key={currentIndex}
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{
                  x: { type: "spring", stiffness: 300, damping: 30 },
                  opacity: { duration: 0.2 },
                }}
                className="absolute inset-0 flex flex-col items-center justify-center p-12"
              >
                <p className="mb-8 font-serif text-xl italic text-brand-on-surface-variant opacity-60">
                  Frase del Día
                </p>
                <Quote size={48} className="mb-8 text-brand-outline-variant opacity-30" />
                <h2 className="mb-8 font-serif text-3xl italic leading-tight text-brand-primary md:text-5xl">
                  {quotes[currentIndex].text}
                </h2>
                <p className="font-sans text-xs font-bold uppercase tracking-[0.2em] text-brand-on-surface-variant">
                  {quotes[currentIndex].source}
                </p>

                <div className="mt-10 flex w-full justify-center gap-8 border-t border-brand-outline-variant/10 pt-8">
                  <button className="group flex items-center gap-2 text-brand-on-surface-variant transition-colors hover:text-brand-primary">
                    <Heart size={18} className="transition-all group-hover:fill-brand-primary" />
                    <span className="font-sans text-sm font-medium">Me gusta</span>
                  </button>
                  <button className="group flex items-center gap-2 text-brand-on-surface-variant transition-colors hover:text-brand-primary">
                    <Share2 size={18} />
                    <span className="font-sans text-sm font-medium">Compartir</span>
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          <button
            onClick={nextQuote}
            className="absolute -right-4 z-20 flex h-12 w-12 items-center justify-center rounded-full bg-brand-surface-lowest text-brand-on-surface shadow-ambient transition-all hover:scale-110 hover:text-brand-primary active:scale-95 md:-right-16 md:h-14 md:w-14"
          >
            <ChevronRight size={24} />
          </button>
        </div>
      </div>
    </section>
  );
}
