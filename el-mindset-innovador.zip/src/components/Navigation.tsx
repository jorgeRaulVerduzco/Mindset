import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const navLinks = [
  { name: "Hero", href: "#hero" },
  { name: "Frase del Día", href: "#frase" },
  { name: "Explorar", href: "#explorar" },
  { name: "Descargar", href: "#descargar" },
];

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        isScrolled ? "glass-nav py-3 shadow-ambient" : "py-6"
      }`}
    >
      <div className="mx-auto flex max-w-screen-2xl items-center justify-between px-8">
        <div className="font-serif text-2xl font-medium italic text-brand-on-surface">
          Yaqui Valley
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="font-sans text-sm font-medium tracking-wide text-brand-on-surface-variant transition-colors hover:text-brand-on-surface"
            >
              {link.name}
            </a>
          ))}
          <button className="gradient-btn rounded-md px-6 py-2.5 text-xs font-semibold uppercase tracking-widest text-brand-surface-lowest shadow-sm hover:opacity-90 active:scale-95 transition-all">
            Empezar
          </button>
        </nav>

        {/* Mobile Menu Toggle */}
        <button
          className="p-2 text-brand-on-surface md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute left-0 top-full w-full bg-brand-surface-lowest px-8 py-6 shadow-ambient md:hidden"
          >
            <nav className="flex flex-col gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="font-sans text-lg font-medium text-brand-on-surface-variant"
                >
                  {link.name}
                </a>
              ))}
              <button className="gradient-btn w-full rounded-md py-4 text-center text-sm font-semibold uppercase tracking-widest text-brand-surface-lowest">
                Empezar
              </button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
