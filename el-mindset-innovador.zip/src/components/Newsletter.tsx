import { Star } from "lucide-react";
import { motion } from "motion/react";

export default function Newsletter() {
  return (
    <section id="descargar" className="bg-brand-surface-lowest py-40">
      <div className="mx-auto max-w-screen-md px-8 text-center">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-6 font-serif text-5xl italic leading-tight text-brand-on-surface"
        >
          Llévate el libro completo
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="mb-12 font-sans text-xl text-brand-on-surface-variant opacity-80"
        >
          Únete a la comunidad de innovadores que ya están transformando su mentalidad.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mx-auto max-w-lg rounded-xl bg-brand-surface-low p-8 shadow-ambient"
        >
          <div className="flex flex-col space-y-6">
            <input
              type="email"
              placeholder="Tu mejor correo electrónico"
              className="w-full border-b border-brand-outline-variant/40 bg-transparent py-4 text-center font-sans text-lg text-brand-on-surface outline-none transition-colors focus:border-brand-primary placeholder:opacity-50"
            />
            <button className="gradient-btn w-full rounded-md py-5 font-sans text-sm font-semibold uppercase tracking-widest text-brand-surface-lowest shadow-lg transition-transform hover:scale-[1.01] active:scale-95">
              Quiero mi copia
            </button>
          </div>
        </motion.div>

        <div className="mt-12 flex flex-col items-center gap-4">
          <div className="flex text-brand-primary">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star key={i} size={20} fill="currentColor" stroke="none" />
            ))}
          </div>
          <p className="font-sans text-sm font-medium text-brand-on-surface-variant opacity-60">
            Valorado por cientos de lectores
          </p>
        </div>
      </div>
    </section>
  );
}
