import { motion } from "motion/react";

export default function Hero() {
  return (
    <section id="hero" className="relative mx-auto max-w-screen-xl overflow-hidden px-8 pb-40 pt-32">
      {/* Decorative Origami Icons (Simulated) */}
      <motion.div
        initial={{ opacity: 0, rotate: 0 }}
        animate={{ opacity: 0.2, rotate: 12 }}
        transition={{ duration: 1.5, delay: 0.5 }}
        className="absolute right-20 top-20 text-brand-outline"
      >
        <svg
          width="64"
          height="64"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M22 2L11 13" />
          <path d="M22 2L15 22L11 13L2 9L22 2Z" />
        </svg>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, rotate: 0 }}
        animate={{ opacity: 0.2, rotate: -12 }}
        transition={{ duration: 1.5, delay: 0.7 }}
        className="absolute bottom-20 left-10 text-brand-outline"
      >
        <svg
          width="48"
          height="48"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M4 15l4 4l12-12" />
        </svg>
      </motion.div>

      <div className="relative z-10 grid grid-cols-1 items-center gap-16 md:grid-cols-12">
        <div className="md:col-span-7">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 font-sans text-xs font-bold uppercase tracking-[0.2em] text-brand-on-surface-variant"
          >
            por: Jesús A. Gaxiola
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8 font-serif text-6xl italic leading-[1.1] text-brand-primary md:text-8xl"
          >
            El Mindset <br /> Innovador
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-10 max-w-lg font-sans text-xl leading-relaxed text-brand-on-surface-variant opacity-80"
          >
            +100 frases sobre innovación que invitan a detenerse y reflexionar.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col gap-4 sm:flex-row"
          >
            <div className="flex-grow">
              <input
                type="email"
                placeholder="Ingresa tu correo"
                className="w-full border-b border-brand-outline-variant/40 bg-transparent py-4 font-sans text-lg text-brand-on-surface outline-none transition-colors focus:border-brand-primary placeholder:opacity-50"
              />
            </div>
            <button className="gradient-btn whitespace-nowrap rounded-md px-8 py-4 font-sans text-sm font-semibold uppercase tracking-wider text-brand-surface-lowest shadow-lg transition-transform hover:scale-[1.02] active:scale-95">
              Descargar gratis
            </button>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="md:col-span-5"
        >
          <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-brand-surface-low p-8 shadow-ambient group">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDa0apM_XdYLkdpWXdj8vavvuESAcWVdyqxTV-5RTml5AXIClwos3p1PpBzD8UTntHzsOyrKl1so-HoCWZnz0-C0d-AP8CiEBS703iMsPhViNL1AAloS5T85m1xo69HXQu9uWWpwTIKS8gJ5R1fy0iO0RTW30y49AoNx-AIrQ4jdm3dnwNfy4NNX0LymPeeGvvwzO31tJy1sBoC5CMgU5RL_hCi2GhagmnuKYjNIcCn4TlzKeiony8dWuBifH-Yoj2UHrBLkGGogb2V"
              alt="Portada del libro El Mindset Innovador"
              className="absolute inset-0 h-full w-full object-cover opacity-90 transition-transform duration-700 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-surface/80 via-transparent to-transparent" />
            <div className="relative z-10 flex h-full flex-col items-center justify-center text-center">
              <div className="mb-6 h-1 w-16 rounded-full bg-brand-primary" />
              <h2 className="font-serif text-3xl italic leading-tight text-brand-on-surface">
                Descubre <br /> la Chispa
              </h2>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
