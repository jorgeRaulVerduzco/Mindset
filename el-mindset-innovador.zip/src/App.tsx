/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navigation from "./components/Navigation";
import Hero from "./components/Hero";
import QuoteCarousel from "./components/QuoteCarousel";
import ExploreGrid from "./components/ExploreGrid";
import Newsletter from "./components/Newsletter";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-brand-surface selection:bg-brand-primary selection:text-brand-surface-lowest">
      <Navigation />
      <main>
        <Hero />
        <QuoteCarousel />
        <ExploreGrid />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
}
